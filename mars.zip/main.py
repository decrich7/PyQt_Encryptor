from flask import Flask, render_template, redirect, request, abort


app = Flask(__name__, template_folder='templates')
app.config['SECRET_KEY'] = 'fgg90dfg8-g98-gqep675-mx0g-fgfgdfg'


@app.route('/')
def logout():
    return render_template('index.html')


if __name__ == '__main__':
    app.run(port=80, host='127.0.0.1')