# -*- coding: utf-8 -*-

from flask import Flask, render_template, redirect, request, abort
import os
UPLOAD_FOLDER = 'static/img'

app = Flask(__name__, template_folder='templates')
app.config['SECRET_KEY'] = 'fgg90dfg8-g98-gqep675-mx0g-fgfgdfg'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

list_file_name = []
@app.route('/', methods=['POST', 'GET'])
def index():
    global list_file_name
    if request.method == 'GET':
        return render_template('index.html', list_img=list_file_name)
    elif request.method == 'POST':
        f = request.files['file']
        f.save(os.path.join(app.config['UPLOAD_FOLDER'], f.filename))
        list_file_name.append(f.filename)
        print(list_file_name, 1324)
        return render_template('index.html', list_img=list_file_name)


if __name__ == '__main__':
    app.run(port=80, host='127.0.0.1')